$("document").ready(function(){
    console.log($("body").attr("id"));
});